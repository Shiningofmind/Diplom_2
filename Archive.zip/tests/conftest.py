import pytest
from data import EXISTED_PAYLOAD
from methods.create_user_methods import CreateUser
from methods.login_user_methods import LoginUser
from methods.changing_user_data_methods import UserProfile


@pytest.fixture(scope="function")
def user_fixture():
    user_methods = CreateUser()
    payload = user_methods.generate_user_data()
    token = user_methods.create_user(payload).json().get('accessToken')
    yield payload, token
    user_methods.delete_user(token)

@pytest.fixture(scope="module")
def existing_user_fixture():
    login_user = LoginUser()
    token = login_user.get_token(EXISTED_PAYLOAD["email"], EXISTED_PAYLOAD["password"])
    return token


@pytest.fixture(scope="function")
def user_methods():
    """Фикстура для работы с созданием пользователей."""
    return CreateUser()


@pytest.fixture(scope="function")
def login_user():
    """Фикстура для работы с логином пользователей."""
    return LoginUser()


@pytest.fixture(scope="function")
def profile_methods():
    """Фикстура для работы с профилем пользователей."""
    return UserProfile()